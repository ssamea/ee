package com.example.graduation;

public class DistributionVo {
    String count;

    public DistributionVo(String count) {
        this.count = count;
    }

    public String getCount() {
        return count;
    }
}
